function cargarEjercicio(ruta) {
    document.getElementById('visor').src = ruta;
}
